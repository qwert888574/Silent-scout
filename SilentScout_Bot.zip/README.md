# SilentScout Telegram Bot

A GPT-powered Telegram bot that fetches Amazon product data and unlocks premium features using Gumroad licenses.

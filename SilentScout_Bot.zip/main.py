from flask import Flask, request
import os

app = Flask(__name__)

@app.route('/')
def home():
    return 'SilentScout Bot is Live!'

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    # Here you'd handle Telegram update logic
    return 'ok'

if __name__ == '__main__':
    app.run()
